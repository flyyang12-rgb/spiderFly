"""Write a plain .xlsx table to a new file, using the shared instruction entry."""

from __future__ import annotations

from datetime import datetime, time, timedelta
from io import BytesIO
from math import isfinite
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.utils.exceptions import IllegalCharacterError
from pydantic import Field

from .core import Instruction, InstructionError, InstructionModel
from .excel import CellValue


INSTRUCTION_ID = "excel.write"


class WriteExcelInput(InstructionModel):
    file_path: str = Field(min_length=1, description="新建 .xlsx 文件的保存路径，所在目录须已存在")
    columns: list[str] = Field(min_length=1, max_length=16384, description="按保存顺序填写列名")
    rows: list[dict[str, CellValue]] = Field(max_length=1048575, description="每行按列名保存数据；键须与列名一致")
    sheet_name: str = Field(default="数据", min_length=1, max_length=31, description="工作表名称")


class WriteExcelOutput(InstructionModel):
    file_path: str = Field(description="生成文件的绝对路径")
    sheet_name: str = Field(description="生成的工作表名称")
    row_count: int = Field(ge=0, description="写入的数据行数，不含表头；含传入的全空行")


def _failure(code: str, message: str) -> InstructionError:
    return InstructionError(code, INSTRUCTION_ID, "execute", message)


def _check_table(inputs: WriteExcelInput) -> None:
    if (
        not inputs.sheet_name.strip()
        or any(character in inputs.sheet_name for character in "\\/*?:[]")
        or inputs.sheet_name.startswith("'")
        or inputs.sheet_name.endswith("'")
    ):
        raise _failure("EXCEL_SHEET_INVALID", "工作表名称无效，请使用普通文字名称。")
    if any(not column or column != column.strip() for column in inputs.columns):
        raise _failure("EXCEL_HEADER_INVALID", "列名不能为空，也不能在首尾带空格。")
    expected = set(inputs.columns)
    if len(expected) != len(inputs.columns):
        raise _failure("EXCEL_HEADER_INVALID", "列名不能重复。")
    for row_number, row in enumerate(inputs.rows, start=2):
        if set(row) != expected:
            raise _failure("EXCEL_ROW_INVALID", f"第 {row_number} 行的字段与列名不一致，请补齐缺列或移除多余字段。")


def _set_cell(worksheet, row: int, column: int, value: CellValue) -> None:
    location = f"第 {row} 行、第 {column} 列"
    if isinstance(value, str) and len(value) > 32767:
        raise _failure("EXCEL_VALUE_INVALID", f"{location}的文字超过 Excel 单元格长度限制。")
    if isinstance(value, float) and not isfinite(value):
        raise _failure("EXCEL_VALUE_INVALID", f"{location}不是有限数字。")
    if type(value) is int and abs(value) > 999999999999999:
        raise _failure("EXCEL_VALUE_INVALID", f"{location}的整数超过 15 位，请以文字传入以保留完整内容。")
    if isinstance(value, (datetime, time)) and value.tzinfo is not None:
        raise _failure("EXCEL_VALUE_INVALID", f"{location}的日期或时间带有时区，请先转换为所需的本地时间。")
    if isinstance(value, (datetime, time, timedelta)):
        microseconds = value.microseconds if isinstance(value, timedelta) else value.microsecond
        if microseconds % 1000:
            raise _failure("EXCEL_VALUE_INVALID", f"{location}的时间精度小于毫秒，请先明确需要保留的精度。")
    try:
        cell = worksheet.cell(row=row, column=column, value=value)
        if isinstance(value, str):
            # Preserve literal strings, including leading '=' and Excel error names.
            cell.data_type = "s"
    except (IllegalCharacterError, TypeError, ValueError) as exc:
        raise _failure("EXCEL_VALUE_INVALID", f"{location}包含无法写入 Excel 的内容。") from exc


def _build_workbook(inputs: WriteExcelInput) -> bytes:
    workbook = Workbook(iso_dates=True)
    try:
        worksheet = workbook.active
        worksheet.title = inputs.sheet_name
        for column, name in enumerate(inputs.columns, start=1):
            _set_cell(worksheet, 1, column, name)
        for row_number, row in enumerate(inputs.rows, start=2):
            for column, name in enumerate(inputs.columns, start=1):
                _set_cell(worksheet, row_number, column, row[name])
        with BytesIO() as buffer:
            workbook.save(buffer)
            return buffer.getvalue()
    except InstructionError:
        raise
    except (TypeError, ValueError) as exc:
        raise _failure("EXCEL_VALUE_INVALID", "工作表名称或数据无法保存为 Excel，请检查输入内容。") from exc
    finally:
        workbook.close()


def write_excel(inputs: WriteExcelInput) -> dict[str, object]:
    path = Path(inputs.file_path).absolute()
    if path.suffix.lower() != ".xlsx":
        raise _failure("EXCEL_FORMAT_UNSUPPORTED", "保存路径必须以 .xlsx 结尾。")
    _check_table(inputs)
    payload = _build_workbook(inputs)
    try:
        destination = path.open("xb")
    except FileExistsError as exc:
        raise _failure("EXCEL_FILE_EXISTS", "目标文件已存在，请换一个保存名称。") from exc
    except (FileNotFoundError, NotADirectoryError) as exc:
        raise _failure("EXCEL_DIRECTORY_MISSING", "保存目录不存在，请先创建目录或更换路径。") from exc
    except OSError as exc:
        raise _failure("EXCEL_WRITE_FAILED", "无法创建文件，请检查保存路径和目录权限。") from exc

    try:
        with destination:
            destination.write(payload)
    except BaseException as exc:
        # Only this invocation's newly created file can reach this cleanup.
        try:
            path.unlink()
        except OSError as cleanup_error:
            if not isinstance(exc, Exception):
                exc.add_note("本次新建的目标文件未能清理，请检查残留文件。")
                raise exc from cleanup_error
            raise _failure("EXCEL_WRITE_INCOMPLETE", "写入未完成，目标位置残留本次新建文件，请检查后再处理。") from cleanup_error
        if not isinstance(exc, Exception):
            raise
        raise _failure("EXCEL_WRITE_FAILED", "写入失败，本次未完成的新文件已清理。") from exc
    return {"file_path": str(path), "sheet_name": inputs.sheet_name, "row_count": len(inputs.rows)}


def verify_excel_write(inputs: WriteExcelInput, result: WriteExcelOutput) -> bool:
    if (
        result.file_path != str(Path(inputs.file_path).absolute())
        or result.sheet_name != inputs.sheet_name
        or result.row_count != len(inputs.rows)
    ):
        return False
    with Path(result.file_path).open("rb") as source:
        workbook = load_workbook(source, read_only=True, data_only=False, keep_links=False)
        try:
            if workbook.sheetnames != [inputs.sheet_name]:
                return False
            worksheet = workbook[inputs.sheet_name]
            return (
                worksheet.max_row == len(inputs.rows) + 1
                and worksheet.max_column == len(inputs.columns)
                and [cell.value for cell in worksheet[1]] == inputs.columns
            )
        finally:
            workbook.close()


WRITE_EXCEL = Instruction(
    instruction_id=INSTRUCTION_ID,
    name="写入 Excel",
    version="0.1.0",
    description="按列名顺序把数据写成新的 .xlsx 文件；字符串按文字保存，目标文件已存在时拒绝覆盖。",
    input_model=WriteExcelInput,
    output_model=WriteExcelOutput,
    handler=write_excel,
    verifier=verify_excel_write,
)
